function validar() {
    var ret_email = validar_email();
    var ret_pass1 = validar_pass1();
    var ret_pass2 = validar_pass2();
    var ret_address = validar_address();
    var ret_state = validar_state();
    var ret_phone = validar_phone();
    var ret_website = validar_website();
    var ret_check = validar_check();
    return ret_email && ret_pass1 && ret_pass2 && ret_address && ret_state && ret_phone && ret_website && ret_check;
}

function validar_check() {
    var check = document.getElementById("check");
    var div = document.getElementById("msj_check");
    if(check.checked == true){
        div.innerText = "";
        div.className = "";
        return true;
    } else {
        div.innerText = 'Debe confirmar sus datos para poder registrarse';
        div.className = 'm-2 text-danger';
        return false;
    }
}

function validar_email() {
    var input = document.getElementById("email");
    var div = document.getElementById("msj_email");
    if (input.value != "") {
        if(input.value.length >= 5) {

            var correo = input.value;
            var pos_arroba = correo.indexOf('@');
            var pos_punto = correo.lastIndexOf('.');
            var arr_correo = correo.split('.');
            var extension = arr_correo[arr_correo.length - 1];
            if(pos_arroba > 3 && (pos_punto - pos_arroba) > 1 && extension.length > 1) {
                div.innerText = "";
                div.className = "";
                return true;
            } else {
                div.innerText = 'El campo "Correo electrónico" no tiene un formato válido';
                div.className = 'm-2 text-danger';
                return false;
            }
        } else {
            div.innerText = 'El campo "Correo electrónico" debe tener al menos 5 caracteres';
            div.className = 'm-2 text-danger';
            return false;
        }
    } else {
        div.innerText = 'El campo "Correo electrónico" es obligatorio';
        div.className = 'm-2 text-danger';
        return false;
    }
    
}


function validar_pass1() {
    var pass1 = document.getElementById("pass1");
    var div = document.getElementById("msj_pass1");
    if (pass1.value != "") {
        if (pass1.value.length < 3 && pass1.value.length > 6){
            div.innerText = "";
            div.className = "";
            return true;
        } else {
            div.innerText = 'La contraseña debe contener entre 3 a 6 caracteres';
            div.className = 'm-2 text-danger';
            return false;
        }
    } else {
        div.innerText = 'El campo "Contraseña" es obligatorio';
        div.className = 'm-2 text-danger';
        return false;
    }

}

function validar_pass2() {
    var pass1 = document.getElementById("pass1");
    var pass2 = document.getElementById("pass2");
    var div = document.getElementById("msj_pass2");
    if (pass2.value != "") {
        if (pass2.value == pass1.value) {
            div.innerText = "";
            div.className = "";
            return true;
        } else {
            div.innerText = 'Las contraseñas no coinciden';
            div.className = 'm-2 text-danger';
            return false;
        }
    } else {
        div.innerText = 'El campo "Repita la contraseña" es obligatorio';
        div.className = 'm-2 text-danger';
        return false;
    }
}

function validar_address(){
    var address = document.getElementById("address");
    var div = document.getElementById("msj_address");
    if (address.value !="") {
        if (address.value.length >= 5 ) {
            div.innerText = "";
            div.className = "";
            return true;
        } else {
            div.innerText = 'Debe ingresar una dirección válida';
            div.className = 'm-2 text-danger';
            return false;
        }
    } else {
        div.innerText = 'El campo "Dirección" es obligatorio';
        div.className = 'm-2 text-danger';
        return false;
        }
}

function validar_state (){
    var state = document.getElementById("state");
    var div = document.getElementById("msj_state");
    var choose = document.getElementById("choose");
    if (state.value == choose.value) {
        div.innerText = 'Debe seleccionar una comuna';
        div.className = 'm-2 text-danger';
        return false;
    } else {
        div.innerText = "";
        div.className = "";
        return true;
    }
}

function validar_phone () {
    var phone = document.getElementById("phone");
    var div = document.getElementById("msj_phone");
    if (phone.value !="") {
        if (phone.value.length == 9) {
            div.innerText = "";
            div.className = "";
            return true;
        } else {
            div.innerText = 'Ingrese un número teléfonico de 9 dígitos';
            div.className = 'm-2 text-danger';
            return false;
        }
    } else {
        div.innerText = 'El campo "Número de teléfono" es obligatorio';
        div.className = 'm-2 text-danger';
        return false;
    }
}

function validar_website() {
    var website = document.getElementById("website");
    var div = document.getElementById("msj_website");
    if (website.value != "") {

            var web = website.value;
            var pre_dom = web.startsWith('www');


            if(pre_dom = website) {
                div.innerText = "";
                div.className = "";
                return true;
            } else {
                div.innerText = 'El campo "Página web personal" no tiene un formato válido';
                div.className = 'm-2 text-danger';
                return false;
            }
    } else {
        div.innerText = 'El campo "Página web personal" es obligatorio';
        div.className = 'm-2 text-danger';
        return false;
    }
    
}


var hobbies = [];
function agregar() {
    var div = document.getElementById("msj_hobbie");
    var hob = document.getElementById("hobbie").value;
    if (hob != "") {
        var aficion = {
            hobbie : hob,
        };
        hobbies.push(aficion);
        actualizar();
        div.className = "m-2 text-success";
        div.innerText = "Añadido correctamente";
        limpiar();
    } else {
        div.className = "m-2 text-danger";
        div.innerText = "Debe añadir mínimo 2 aficiones";
    }
}
function actualizar() {
    var ul = document.getElementById("lista");
    ul.innerHTML = "";
    for (var i = 0; i < hobbies.length; i++) {
        var li = document.createElement("li");
        li.innerText = hobbies[i].hobbie ;
        li.className = "list-group-item";
        li.id = i;
        li.addEventListener("click", function(){
            this.remove();
            personas.splice(this.id, 1);
        });
        ul.appendChild(li);
    }
}
function limpiar() {
    document.getElementById("hobbie").value = "";

}
function limpiar_mensaje() {
    var div = document.getElementById("msj_hobbie");
    div.innerText = "";
    div.className = "";
}